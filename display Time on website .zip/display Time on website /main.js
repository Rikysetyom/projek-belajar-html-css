setInterval(() => {
  let time = document.getElementById("curent-time");
  let date = new Date();
  time.innerHTML = date.toLocaleTimeString();

},1000);
